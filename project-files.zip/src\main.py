
import csv
from pathlib import Path
from datetime import datetime, timedelta
import calendar

BASE_DIR = Path(__file__).resolve().parent.parent
TAGS_FILE = BASE_DIR / "data" / "tags.csv"

SINGLE_RATES = {
    "CAR": 65,
    "LCV": 105,
    "BUS_TRUCK": 220,
    "MAV": 345
}

crossing_history = {}
active_passes = {}


def load_tags():
    with open(TAGS_FILE, "r", newline="", encoding="utf-8") as file:
        reader = csv.DictReader(file)
        tags = {}

        for row in reader:
            row["opening_balance"] = float(row["opening_balance"])
            row["local_resident"] = row["local_resident"].lower() == "true"
            row["exempt"] = row["exempt"].lower() == "true"
            row["blacklisted"] = False
            tags[row["tag_id"]] = row

    return tags


def find_tag(tags, tag_id):
    return tags.get(tag_id)


def calculate_fare(vehicle_class):
    return SINGLE_RATES.get(vehicle_class, 0)


def calculate_crossing_fare(tag_id, vehicle_class, crossing_time):
    fare = calculate_fare(vehicle_class)
    history = crossing_history.setdefault(tag_id, [])

    if not history or crossing_time - history[0] > timedelta(hours=24):
        history.clear()

    if len(history) == 1:
        fare *= 0.5
        outcome = "RETURN"
    else:
        outcome = "SINGLE"

    history.append(crossing_time)
    return fare, outcome


def recharge_tag(tag, amount):
    if amount < 100:
        return "REJECTED_MINIMUM"

    tag["opening_balance"] += amount

    if tag["opening_balance"] > 0:
        tag["blacklisted"] = False

    return "OK"


def buy_pass(tag, pass_type, purchase_time):
    """Purchase a monthly pass using cash."""

    tag_id = tag["tag_id"]
    vehicle_class = tag["registered_class"]

    last_day = calendar.monthrange(
        purchase_time.year, purchase_time.month
    )[1]

    valid_to = purchase_time.replace(
        day=last_day, hour=23, minute=59, second=59
    )

    if pass_type == "MONTHLY_LOCAL":
        if vehicle_class != "CAR" or not tag["local_resident"]:
            return "REJECTED", 0

        price = 330
        trips = None

    elif pass_type == "TRIP_50":
        if vehicle_class == "CAR" and tag["local_resident"]:
            return "REJECTED", 0

        price = 30 * calculate_fare(vehicle_class)
        trips = 50

    else:
        return "REJECTED", 0

    active_passes[tag_id] = {
        "type": pass_type,
        "valid_from": purchase_time,
        "valid_to": valid_to,
        "remaining_trips": trips
    }

    return "SOLD", price


def use_pass(tag_id, crossing_time):
    """Check and apply an active monthly pass."""

    pass_info = active_passes.get(tag_id)

    if not pass_info:
        return False

    if not (pass_info["valid_from"] <= crossing_time <= pass_info["valid_to"]):
        return False

    if pass_info["type"] == "MONTHLY_LOCAL":
        return True

    if pass_info["remaining_trips"] > 0:
        pass_info["remaining_trips"] -= 1
        return True

    return False


def process_crossing(tag, crossing_time):
    tag_id = tag["tag_id"]
    vehicle_class = tag["registered_class"]
    single_fare = calculate_fare(vehicle_class)

    if tag["exempt"]:
        return {
            "outcome": "EXEMPT",
            "fare": 0,
            "balance": tag["opening_balance"],
            "flags": []
        }

    if tag["blacklisted"]:
        return {
            "outcome": "CASH_BLACKLISTED",
            "fare": single_fare * 2,
            "balance": tag["opening_balance"],
            "flags": ["BLACKLISTED"]
        }

    if use_pass(tag_id, crossing_time):
        return {
            "outcome": "PASS",
            "fare": 0,
            "balance": tag["opening_balance"],
            "flags": []
        }

    fare, outcome = calculate_crossing_fare(
        tag_id, vehicle_class, crossing_time
    )

    tag["opening_balance"] -= fare
    flags = []

    if tag["opening_balance"] < 0:
        tag["blacklisted"] = True
        flags.append("BLACKLISTED")

    if tag["opening_balance"] < 2 * single_fare:
        flags.append("LOW_BALANCE")

    return {
        "outcome": outcome,
        "fare": fare,
        "balance": tag["opening_balance"],
        "flags": flags
    }


if __name__ == "__main__":

    tags = load_tags()

    print("================================")
    print("       RFID TOLL ENGINE")
    print("================================")
    print("Total registered tags:", len(tags))

    # Find a sample tag
    tag = find_tag(tags, "TAG-0001")

    if tag:
        print("\nTag ID:", tag["tag_id"])
        print("Vehicle class:", tag["registered_class"])
        print("Starting balance:", tag["opening_balance"])

        # Demonstrate pass purchase
        purchase_time = datetime(2026, 10, 15, 9, 40)

        status, price = buy_pass(
            tag, "TRIP_50", purchase_time
        )

        print("\nPass purchase:", status)
        print("Pass price: Rs.", price)

        # Demonstrate crossing
        result = process_crossing(
            tag, datetime(2026, 10, 15, 10, 0)
        )

        print("\nCrossing outcome:", result["outcome"])
        print("Fare: Rs.", result["fare"])
        print("Balance: Rs.", result["balance"])

    else:
        print("Tag not found!")
